//
//  MLLineGraphView.m
//  MinPairs
//
//  Created by Brandon on 2014-04-25.
//  Copyright (c) 2014 MobiLearning. All rights reserved.
//

#import "MLLineGraphView.h"
#import "MLGraphicsLegend.h"

@implementation MLLineGraphView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
    }
    return self;
}

-(void) awakeFromNib
{
    [self setNeedsDisplay];
}

-(void) printDeviceInfo
{
    NSLog(@"[UIDevice currentDevice].model: %@",[UIDevice currentDevice].model);
    NSLog(@"[UIDevice currentDevice].description: %@",[UIDevice currentDevice].description);
    NSLog(@"[UIDevice currentDevice].localizedModel: %@",[UIDevice currentDevice].localizedModel);
    NSLog(@"[UIDevice currentDevice].name: %@",[UIDevice currentDevice].name);
    NSLog(@"[UIDevice currentDevice].systemVersion: %@",[UIDevice currentDevice].systemVersion);
    NSLog(@"[UIDevice currentDevice].systemName: %@",[UIDevice currentDevice].systemName);
}

-(void) drawLegendTest:(MLGraphics*)graphics
{
    MLGraphicsLegend* legend = [[MLGraphicsLegend alloc] init: graphics];
    
    [legend setOutlineColour:0 withGreen:0 withBlue:0 withAlpha:0];
    [legend setBackgroundColour:224.0f/0xFF withGreen:224.0f/0xFF withBlue:224.0f/0xFF withAlpha: 0.5];

    [legend setDimensions:20 withY:75 withWidth:75 withHeight:80];
    
    Colour titleColour = [graphics CreateColour:0 withGreen:0 withBlue:0 withAlpha:1];
    [legend setTitle:@"Legend" withColour: titleColour];
    [legend addItem:@"Item1" withRed:1 withGreen:0 withBlue:0 withAlpha:1];
    [legend addItem:@"Item2" withRed:0 withGreen:1 withBlue:0 withAlpha:1];
    [legend addItem:@"Item3" withRed:0 withGreen:0 withBlue:1 withAlpha:1];
    [legend draw];
}

-(CGPoint) getRandomPoint
{
    uint32_t height = self.frame.size.height;
    uint32_t width = self.frame.size.width;
    
    uint32_t rx = arc4random_uniform(width);
    uint32_t ry = arc4random_uniform(height);
    return CGPointMake(rx, ry);
}

-(Colour)colourWithAlpha:(Colour)colour withAlpha:(float)alpha
{
    CGFloat R, G, B, A;
    [colour getRed:&R green:&G blue:&B alpha:&A];
    return [UIColor colorWithRed: R green: G blue: B alpha: alpha];
}

-(void) drawTestGraph:(MLGraphics*)graphics withColour:(Colour)colour
{
    /** Generate Random Points **/
    
    CGPoint testPoints[75];
    
    testPoints[0].x = 0;
    testPoints[0].y = self.frame.size.height - arc4random_uniform(self.frame.size.height / 5);
    
    for (int i = 1; i < sizeof(testPoints) / sizeof(CGPoint); ++i)
    {
        CGPoint t = [self getRandomPoint];
        testPoints[i].x = testPoints[i - 1].x + t.x / 20;
        
        int height = self.frame.size.height;
        if (t.y > (height / 3))
        {
            testPoints[i].y = testPoints[i - 1].y - (t.y / 25);
        }
        else
        {
            testPoints[i].y = testPoints[i - 1].y + (t.y / 15);
        }
    }
    
    
    /** Draw Line Segments **/
    
    [graphics SetStrokeColour: colour];
    [graphics SetFillColour: colour];
    
    [graphics BeginDrawing];
    [graphics MoveTo: -1 withY: self.frame.size.height + 1];
    [graphics LineTo: testPoints[0].x withY: testPoints[0].y];
    
    for (int i = 1; i < sizeof(testPoints) / sizeof(CGPoint); ++i)
    {
        [graphics LineTo: testPoints[i].x withY: testPoints[i].y];
    }
    
    [graphics LineTo: self.frame.size.width withY: self.frame.size.height];
    [graphics EndDrawing: kCGPathStroke];
    
    
    /** Draw Line Endings **/
    
    [graphics SetFillColour: colour];
    for (int i = 0; i < sizeof(testPoints) / sizeof(CGPoint); ++i)
    {
        [graphics BeginDrawing];
        [graphics DrawCircle: testPoints[i].x withY: testPoints[i].y withRadius: 2];
        [graphics EndDrawing: kCGPathFill];
    }
    
    
    /** Gradient-Fill below the graphics **/
    
    size_t num_locations = 2;
    CGFloat locations[2] = {0.0, 1.0};
    CGFloat components[8] = {0};
    CGPoint startPoint, endPoint;
    startPoint.x = 0;
    startPoint.y = self.frame.size.height;
    endPoint.x = 0;
    endPoint.y = 0;
    
    [colour getRed: &components[0] green: &components[1] blue: &components[2] alpha: &components[3]];
    [colour getRed: &components[4] green: &components[5] blue: &components[6] alpha: &components[7]];
    components[3] = 0.1f;
    components[7] = 0.9f;
    
    CGColorSpaceRef colorspace = CGColorSpaceCreateDeviceRGB();
    CGGradientRef gradient = CGGradientCreateWithColorComponents(colorspace, components, locations, num_locations);
    
    
    [graphics SetStrokeColour: colour];
    [graphics SetFillColour: colour];
    
    [graphics BeginDrawing];
    [graphics MoveTo: -1 withY: self.frame.size.height + 1];
    [graphics LineTo: testPoints[0].x withY: testPoints[0].y];
    
    for (int i = 1; i < sizeof(testPoints) / sizeof(CGPoint); ++i)
    {
        [graphics LineTo: testPoints[i].x withY: testPoints[i].y];
    }
    
    [graphics LineTo: self.frame.size.width withY: self.frame.size.height];

    CGContextSaveGState([graphics GetCurrentSurface]);
    CGContextClip([graphics GetCurrentSurface]);
    CGContextDrawLinearGradient([graphics GetCurrentSurface], gradient, startPoint, endPoint, 0);
    CGContextRestoreGState([graphics GetCurrentSurface]);
    CGColorSpaceRelease(colorspace);
    CGGradientRelease(gradient);
}

- (void)drawRect:(CGRect)rect
{
    MLGraphics* graphics = [[MLGraphics alloc] init];
    
    [self drawTestGraph:graphics withColour: [graphics CreateColour:1 withGreen:0 withBlue:0 withAlpha:1]];
    [self drawTestGraph:graphics withColour: [graphics CreateColour:0 withGreen:1 withBlue:0 withAlpha:1]];
    [self drawTestGraph:graphics withColour: [graphics CreateColour:0 withGreen:0 withBlue:1 withAlpha:1]];
    [self drawLegendTest: graphics];
}

@end
