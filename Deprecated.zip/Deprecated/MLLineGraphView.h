//
//  MLLineGraphView.h
//  MinPairs
//
//  Created by Brandon on 2014-04-25.
//  Copyright (c) 2014 MobiLearning. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MLGraphics.h"

@interface MLLineGraphView : UIView

@end
