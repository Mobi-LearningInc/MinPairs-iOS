//
//  MLiPadUpdateViewDelegate.h
//  MinPairs
//
//  Created by Brandon on 2014-04-29.
//  Copyright (c) 2014 MobiLearning. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol MLiPadUpdateViewDelegate <NSObject>
@required
-(void)updateView:(UIView*)view;
@end
